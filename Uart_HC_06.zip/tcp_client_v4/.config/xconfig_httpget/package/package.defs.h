/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-B21
 */

#ifndef xconfig_httpget__
#define xconfig_httpget__



#endif /* xconfig_httpget__ */ 
